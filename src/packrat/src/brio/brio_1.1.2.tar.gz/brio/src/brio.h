#pragma once

#include <Rinternals.h>

FILE* open_with_widechar_on_windows(SEXP path, const char* mode);
