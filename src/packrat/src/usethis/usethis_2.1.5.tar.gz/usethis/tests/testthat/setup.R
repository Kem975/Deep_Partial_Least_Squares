pre_test_options <- options(
  usethis.quiet = TRUE
)
