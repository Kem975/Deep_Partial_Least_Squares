# use_tibble() Imports tibble

    Code
      use_tibble()
    Message <message>
      v Adding 'tibble' to Imports field in DESCRIPTION
      v Adding '@importFrom tibble tibble' to 'R/mypackage-package.R'
      * Document a returned tibble like so:
        #' @return a [tibble][tibble::tibble-package]

