
#ifndef RETICULATE_EVENT_LOOP_H
#define RETICULATE_EVENT_LOOP_H

namespace reticulate {
namespace event_loop {

void initialize();

} // namespace event_loop
} // namespace reticulate

#endif // RETICULATE_EVENT_LOOP_H
