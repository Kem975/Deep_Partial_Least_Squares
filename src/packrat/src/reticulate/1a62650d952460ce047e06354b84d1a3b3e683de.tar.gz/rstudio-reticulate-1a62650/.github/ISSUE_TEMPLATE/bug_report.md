---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

<!--
When filing a bug report, please provide a reproducible example if at all possible. This implies providing a snippet of R and / or Python code that we can copy, paste, and run to immediately observe the issue. If this is not possible, then please provide as much detail as possible to assist us in reproducing the issue locally. The output of utils::sessionInfo() and reticulate::py_config() will often be helpful.

If your issue is not reproducible, it is unlikely that we will be able to help.
-->
