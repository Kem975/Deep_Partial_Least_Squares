# tfruns 1.5.0

# tfruns 1.4.0.9000

* Added a `NEWS.md` file to track changes to the package. (#56)
* Added GitHub actions CI and removed Travis. (#54)
* Fixed issue with precision of serialized metrics and flags. (#55)
