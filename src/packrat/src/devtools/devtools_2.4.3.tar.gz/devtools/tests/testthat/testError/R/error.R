f <- function() {
  5 * 10
}



stop("This is an error!")
