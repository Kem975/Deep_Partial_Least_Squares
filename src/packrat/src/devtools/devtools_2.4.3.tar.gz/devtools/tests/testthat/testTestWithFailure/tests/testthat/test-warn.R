test_that("warning from test", {
  warning("Beware!")
})
