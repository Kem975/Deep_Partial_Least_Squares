library(testthat)
library(pls)

test_check("pls")
